<html>
<head>

<meta charset="UTF-8">
<title>Prática 27</title>
<link href="estilos.css" rel="stylesheet">
</head>
<body>
<div class="caixa0">
 <span id="logo"><img src="logo.png"></span>
</div>
<div class="caixa1">
 <h2>CALCULADORA DE NÚMEROS PRIMOS</h2>
 <br>
 <form>
 <p><u>É um número primo?</u></p> <input type="number" name="num" min="0">
 <button class="botao">Confirmar</button> <br><br>
 </form>
 <p>
 <?php
 
 
 ?>
 </p>
 
</div>
</body>
</html>