<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prática 26</title>
    <meta name="author" content="Jaqueline Lima" />

</head>

<body>
    <?php

    echo "Olá mundo! <br>";
    echo "Olá mundo! <br>";
    echo "Olá mundo! <br>";

    $cor = "azul";
    $COR = "amarelo";
    $Cor = "azul claro";

    echo "O meu carro é " . $cor . "<br>";
    echo "A minha cor favorita é " . $COR . "<br>";
    echo "O céu é " . $Cor . "<br>";
    ?>
</body>

</html>