<html>
<head>
<meta charset="UTF-8">
<title>Prática 12</title>
<link href="estilos.css" rel="stylesheet">
</head>
<body> 
<div class="caixa0"> 
    <span id="logo"><img src="logo.png"></span>
</div>
<div class="caixa1" >
	
<img src="ALTERE O NOME DA IMAGEM.png" style="width: 100%;">

</div>
</body>
</html>