<html>

<head>
    <meta charset="UTF-8">
    <title>Login - Prática 31</title>
    <link href="estilos.css" rel="stylesheet">
</head>

<body>

    <div class="caixa0">
        <span id="logo"><img src="logo.png"></span>
    </div>
    <div class="caixa1">
        <h2>LOGIN COM SUCESSO</h2>

        <?php

        //Aqui deverá ser escrito o código php

        ?>

    </div>
</body>

</html>