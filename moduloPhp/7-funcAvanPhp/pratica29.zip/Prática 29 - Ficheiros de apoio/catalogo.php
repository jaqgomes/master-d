<html>
<head>
<meta charset="UTF-8">
<title>Catálogo - Prática 7</title>
<link href="estilos.css" rel="stylesheet">
</head>
<body> 
<div class="caixa0"> 
    <span id="logo"><img src="logo.png"></span>
</div>
<div class="caixa1">
    <h2>CATÁLOGO</h2>
	<p><a href="carrinho.php" class="botao">Ver carrinho</a></p><br>
	<table>
		<thead>
			<tr>
				<th>Nome do Item</th>
				<th>Preço</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>Dicionário Português</td>
				<td>9.99€</td>
			</tr>
			<tr>
				<td>Livro de Receitas</td>
				<td>14.99€</td>
			</tr>
			<tr>
				<td>Livro para Colorir</td>
				<td>10€</td>
			</tr>
			<tr>
				<td>Mapa das Estradas de Portugal</td>
				<td>24.99€</td>
			</tr>
		</tbody>
	</table>
</div>
</body>
</html>