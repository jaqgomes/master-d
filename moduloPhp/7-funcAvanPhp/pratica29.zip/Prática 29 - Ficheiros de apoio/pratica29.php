<html>
<head>
<meta charset="UTF-8">
<title>Login - Prática 8</title>
<link href="estilos.css" rel="stylesheet">
</head>
<body> 
<div class="caixa0"> 
    <span id="logo"><img src="logo.png"></span>
</div>
<div class="caixa1">
<h2>LOGIN</h2>
<form method="post" action="processologin.php">
<input type="text" id="email" placeholder="Inserir o email" name="email"><br>
<input type="password" id="pwd" placeholder="Inserir a senha" name="pwd"><br><br>
<button type="submit" class="botao">Enviar</button>
</form>

</div>
</body>
</html>